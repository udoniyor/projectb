# ProjectB
ProjectB is a graphical user interface, which allows untrained users to optimize any model that can be
invoked through a command line. The GUI is built on top of a modular Bayesian Optimization library, [pybo](https://github.com/mwhoffman/pybo),
which includes most common acquisition functions and kernels and more.
